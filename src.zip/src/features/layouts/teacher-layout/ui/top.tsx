// src/shared/layouts/TopHeader.tsx
import { Typography } from "@/shared/ui/typography";
import { Button } from "@/shared/ui/button";
import { useAuth } from "@/shared/hooks/use-auth";
import { Link, useRouter } from "@tanstack/react-router";
import clsx from "clsx";
import {
  ArrowRightCircle,
  Home,
  Store,
  Users,
  Folder,
  User,
} from "lucide-react";

const navItems = [
  { name: "대시보드", href: "/teacher/dashboard", icon: Home },
  { name: "교안 스토어", href: "/teacher/store", icon: Store },
  { name: "학생 관리", href: "/teacher/student", icon: Users },
  { name: "교안 보관함", href: "/teacher/content", icon: Folder },
  { name: "내 정보", href: "/teacher/info", icon: User },
];

export function TopHeader() {
  const { my } = useAuth();
  const router = useRouter();
  const currentPath = router.state.location.pathname;

  return (
    <header className="flex items-center justify-between bg-white border-b px-8 py-4">
      {/* 좌측 로고 + 네비 */}
      <div className="flex items-center space-x-8">
        <Link to="/" className="flex flex-col items-start">
          <div className="flex items-center space-x-2">
            <div className="bg-blue-500 rounded-full p-2">
              <ArrowRightCircle size={24} className="text-white" />
            </div>
            <Typography
              variant="h4"
              className="font-semibold text-gray-800"
            >
              리딩브릿지
            </Typography>
          </div>
          <Typography
            variant="p"
            className="text-xs text-gray-500 mt-0.5"
          >
            보호자 대시보드
          </Typography>
        </Link>

        <nav className="flex items-center space-x-4">
          {navItems.map(({ href, name, icon: Icon }) => {
            const isActive = currentPath === href;
            return (
              <Link
                key={href}
                to={href}
                className={clsx(
                  "flex items-center space-x-1 px-3 py-1.5 rounded-full text-sm font-medium transition-colors",
                  isActive
                    ? "bg-blue-100 text-blue-600"
                    : "text-gray-700 hover:bg-gray-100"
                )}
              >
                <Icon
                  size={16}
                  className={
                    isActive ? "text-blue-500" : "text-gray-400"
                  }
                />
                <span>{name}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      {/* 우측 사용자 이름 + 로그인/로그아웃 */}
      <div className="flex items-center space-x-4">
        <Typography variant="p" size="sm" className="text-gray-700">
          {my?.name ?? "로그인 필요"}
        </Typography>
        <Button size="sm" variant="outline">
          {my ? "로그아웃" : "로그인"}
        </Button>
      </div>
    </header>
  );
}
