export { default as TeacherDashboardPage } from "./dashboard/route";
export { default as StudentPage } from "./student";
export { default as ContentManagePage } from "./content";
