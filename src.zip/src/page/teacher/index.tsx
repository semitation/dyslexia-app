export { default as TeacherDashboardPage } from "./dashboard/route";
export { default as StudentManagementPage } from "./student";
export { default as ContentManagePage } from "./content";
export { default as StorePage } from "./store";
export { default as InfoPage } from "./info";
