import { Button } from "@/shared/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/shared/ui/card";
import { Typography } from "@/shared/ui/typography";
import { X } from "lucide-react";
import ReactDOM from "react-dom";

interface StudentInviteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function StudentInviteModal({
  isOpen,
  onClose,
}: StudentInviteModalProps) {
  if (!isOpen) return null;

  const handleBackdropKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter" || e.key === " ") {
      onClose();
    }
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* 백드롭: 클릭뿐 아니라 키보드로도 닫히도록 */}
      <div
        className="absolute inset-0 bg-black bg-opacity-30"
        onClick={onClose}
        role="button"
        tabIndex={0}
        onKeyDown={handleBackdropKeyDown}
        aria-label="Close modal"
      />

      {/* 모달 박스 */}
      <Card className="relative w-full max-w-md rounded-xl bg-white shadow-lg z-10">
        <CardHeader className="flex items-center justify-between px-6 py-4 border-b">
          <CardTitle className="text-lg font-semibold text-gray-900">
            학생 초대
          </CardTitle>
          <button
            type="button"
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </CardHeader>

        <CardContent className="px-6 py-4 space-y-4">
          <Typography variant="p" className="text-sm text-gray-600">
            초대할 학생의 이메일 주소를 입력해주세요.
          </Typography>
          <input
            type="email"
            placeholder="example@school.com"
            className="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </CardContent>

        <div className="flex justify-end px-6 py-4 border-t space-x-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onClose}
          >
            취소
          </Button>
          <Button
            type="button"
            size="sm"
            onClick={() => {
              /* TODO: 초대 API 호출 */
            }}
          >
            초대하기
          </Button>
        </div>
      </Card>
    </div>,
    document.body
  );
}
