import { useMutation } from '@tanstack/react-query';
import { signUp } from '../api/auth';
import type { SignUpFormData, UserType } from '@/shared/types/auth';

export const useSignUp = () => {
  return useMutation({
    mutationFn: (data: SignUpFormData & { userType: UserType; clientId: string }) =>
      signUp({
        ...data,
        type: data.userType,
        interestIds: data.interestIds ?? [],
      }),
    onSuccess: (data) => {
      localStorage.setItem('accessToken', data.accessToken);
      localStorage.setItem('refreshToken', data.refreshToken);
    },
    onError: (error) => {
      console.error('회원가입 실패', error);
    },
  });
};
